<!DOCTYPE html>
<html>
<head>
    <title>Housekeeping Services - Main</title>
    <link rel="stylesheet" href="styles.css"> <!-- Optional styling -->
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 100px;
        }

        h1 {
            color: #2c3e50;
        }

        .role-select {
            margin-top: 40px;
        }

        .role-button {
            display: inline-block;
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            margin: 20px;
            border: none;
            border-radius: 10px;
            text-decoration: none;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .role-button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>

    <h1>Welcome to Housekeeping Services</h1>
    <p>Please select your role to continue:</p>

    <div class="role-select">
        <a href="admin.php" class="role-button">Admin</a>
        <a href="student_guest.php" class="role-button">Student / Guest</a>
        <a href="housekeeper.php" class="role-button">Housekeeper</a>
    </div>

</body>
</html>
