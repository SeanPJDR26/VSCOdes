<?php
session_start();
// Example: Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Welcome Admin</h1>

    <h2>Manage Housekeepers</h2>
    <a href="add_housekeeper.php">Add New Housekeeper</a><br>
    <a href="view_requests.php">View All Requests</a>

    <h2>Reports</h2>
    <a href="report.php">Generate Report</a>
</body>
</html>
